// galleytest fixture package (TEST ONLY).
#let greet(name) = [Hello, #name — from galleytest!]
#let answer = 42
