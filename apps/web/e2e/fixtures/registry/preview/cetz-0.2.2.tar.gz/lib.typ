// Minimal CeTZ stub (TEST FIXTURE ONLY — not real CeTZ).
// Exposes just the surface cetzScaffold touches so the snippet type-checks.
#import "draw.typ"
#let canvas(body) = { let _ = body; [] }
