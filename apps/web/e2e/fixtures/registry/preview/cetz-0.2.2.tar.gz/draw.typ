// CeTZ draw submodule stub (TEST FIXTURE ONLY — not real CeTZ).
#let rect(..args) = none
#let content(..args) = none
